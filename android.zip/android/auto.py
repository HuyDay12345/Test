import os,sys,time
while True:
  os.system("screen -dm -S Scan timeout 6000 sh scan.sh")
  time.sleep(6600)